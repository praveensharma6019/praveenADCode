$(document).ready(function () {
    var $btns = $('.initiatives-title-list a').click(function () {

        if (this.id == 'all') {

            $('#nav-parent > div').fadeIn(450);

        } else {

            var $el = $('.' + this.id).css('display', 'block');

            $('#nav-parent > div').not($el).css('display', 'none');

        }

        $btns.removeClass('active');

        $(this).addClass('active');

    });
    var $btnstab = $('.media-tab a').click(function () {

        if (this.id == 'all') {

            $('.tabcontainerwinner > div').fadeIn(450);

        } else {

            var $el = $('.' + this.id).css('display', 'block');

            $('.tabcontainerwinner > div').not($el).css('display', 'none');

        }

        $btnstab.removeClass('active');

        $(this).addClass('active');
        $(this).parent().parent().find('li').removeClass('active');
        $(this).parent().addClass('active');
    });

    /*Scroll*/
    $(".initiatives-title-list a").click(function (event) {
        var y = $(window).scrollTop();
        y = y + 150;
        $('html, body').animate({ scrollTop: y },800);
    }); 
});

$(function () {
    $(".home-page-banner").owlCarousel({
        loop: !0, responsiveClass: !0, nav: !1, autoplay: !0, autoplayTimeout: 4e3, dots: !0, autoplayHoverPause: !0, responsive: {
            0: {
                items: 1, margin: 0
            }
        }
    }
    ), $(".ready-box-grid").owlCarousel({
        loop: !1, responsiveClass: !0, nav: !1, autoplay: !0, autoplayTimeout: 4e3, dots: !1, autoplayHoverPause: !0, margin: 10, nav: !0, navText: ['<i class="fa fa-chevron-right" aria-hidden="true"></i>', '<i class="fa fa-chevron-right"></i>'], responsive: {
            0: {
                items: 1
            }
            , 480: {
                items: 2
            }
            , 768: {
                items: 3
            }
            , 992: {
                items: 4
            }
        }
    }
    ),
        $(".youtubeVideo").show(), $("header nav > ul li").each(function () {
            $(this).removeClass("active")
        }
        ), $(".marathan-grid-head.perc-circle .chart").easyPieChart({
            easing: "easeOutBounce", size: 40, lineWidth: 4, scaleColor: !1, trackColor: !1, barColor: "#19a491", onStep: function (e, a, o) {
                $(this.el).find(".percent").text(Math.round(o))
            }
        }
        ), $(".chart").easyPieChart({
            easing: "easeOutBounce", size: 40, lineWidth: 4, scaleColor: !1, trackColor: !1, barColor: "#ffffff", onStep: function (e, a, o) {
                $(this.el).find(".percent").text(Math.round(o))
            }
        }
        ), $(".partners-list").owlCarousel({
            loop: !0, responsiveClass: !0, nav: !0, autoplay: !0, dots: !1, autoplayTimeout: 4e3, autoplayHoverPause: !0, responsive: {
                0: {
                    items: 2, margin: 10
                }
                , 768: {
                    items: 3, margin: 15
                }
                , 1025: {
                    items: 4, margin: 15
                }
            }
        }
        ), $(".marathan-detail-grid").owlCarousel({
            loop: !1, responsiveClass: !0, nav: !1, dots: !1, responsive: {
                0: {
                    items: 1, margin: 15
                }
                , 480: {
                    items: 2, margin: 15
                }
            }
        }
        )
}
);